export function composeFunctions(funs) {
    return (v) => {
        let curr = v;
        const sol = [v];
        for (let i = 0; i < funs.length; i++) {
            curr = funs[i](curr);
            sol.push(curr);
        }
        return sol;
    };
}
export function cyclic(values) {
    if (values.length === 0)
        throw new Error("Please pass an array with values");
    let count = 0;
    return () => {
        if (count === values.length) {
            count = 0;
        }
        const sol = values[count];
        count = count + 1;
        return sol;
    };
}
export function rateLimiter(func, limit) {
    if (limit < 0) {
        throw new Error("Please make `limit` a non-negative integer");
    }
    let lim = limit;
    return (x, y) => {
        lim--;
        if (lim >= 0) {
            return func(x, y);
        }
        return undefined;
    };
}
export function byParity(evenFunc, oddFunc) {
    return (n) => {
        if (n % 2 === 0) {
            return evenFunc(n);
        }
        return oddFunc(n);
    };
}
export function vendingMachine(price, stock) {
    if (price < 0) {
        throw new Error("Please enter a positive value for `price`");
    }
    if (stock < 0) {
        throw new Error("Please enter a positive value for `stock`");
    }
    return (amount) => {
        if (amount < price || stock < 1) {
            return undefined;
        }
        stock -= 1;
        return amount - price;
    };
}
export function wageChange(calcNew) {
    return (startWage, startYr, endYr) => {
        if (startYr < 1970 || endYr > 2026 || startYr > endYr || startWage <= 0) {
            return NaN;
        }
        let prev = startWage;
        for (let i = startYr + 1; i <= endYr; i++) {
            prev = calcNew(i, prev);
        }
        if (prev <= 0)
            return NaN;
        return prev;
    };
}
export function factorial(x) {
    if (x === 0 || x === 1)
        return 1;
    if (x < 0)
        throw new Error("Please pass a number >= 0");
    let prod = 1;
    for (let i = x; i > 0; i--) {
        prod *= i;
    }
    return prod;
}
export function sineSeries(x) {
    const term = (k) => {
        return ((-1) ** k * x ** (2 * k + 1)) / factorial(2 * k + 1);
    };
    let lastTerm = 0;
    let total = 0;
    return (moreTerms = 1) => {
        let curr = 0;
        for (let k = lastTerm; k < lastTerm + moreTerms; k++) {
            curr += term(k);
        }
        total += curr;
        lastTerm = lastTerm + moreTerms;
        return total;
    };
}
//# sourceMappingURL=closures.js.map