export class SimulationObject {
    id;
    constructor(id) {
        this.id = id;
    }
    nextTick() { }
}
//# sourceMappingURL=simulation_object.js.map