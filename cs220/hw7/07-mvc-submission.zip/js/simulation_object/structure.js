import { SimulationObject } from "./simulation_object.js";
export function structureFactory(type, id, location) {
    if (type != "house")
        throw new Error("unsupported structure type: " + type);
    return new House(id, location);
}
export class Structure extends SimulationObject {
    location;
    constructor(id, location) {
        super(id);
        this.location = location;
        this.location = location;
    }
}
class House extends Structure {
    getLocation() {
        return this.location;
    }
    image_id = "simpleHouse";
    scale = 1.0;
}
//# sourceMappingURL=structure.js.map