import { Coordinate, linearInterpolate } from "../geometry.js";
import { Sprite } from "../sprite.js";
import { SimulationObject } from "./simulation_object.js";
export function agentFactory(type, id, initialLocation) {
    if (type == "simple_lobster") {
        return new SimpleLobster(id, initialLocation);
    }
    throw new Error("unsupported agent type: " + type);
}
export class Agent extends SimulationObject {
    initial_location;
    currLocation;
    newLocation = { reachedDestination: false, newLocation: new Coordinate(0, 0) };
    destination;
    speed;
    constructor(id, initial_location) {
        super(id);
        this.initial_location = initial_location;
        this.initial_location = initial_location;
        this.currLocation = this.initial_location;
    }
    nextTick() {
        if (this.destination === undefined || this.speed === undefined)
            return;
        this.newLocation = linearInterpolate(this.currLocation, this.destination, this.speed);
        this.currLocation = this.newLocation.newLocation;
    }
    /**
     * Sets this agent's velocity to move towards the
     * specified destination at the given speed.
     */
    startMoving(destination, speed) {
        this.destination = destination;
        this.speed = speed;
    }
    getLocation() {
        return this.currLocation;
    }
}
class SimpleLobster extends Agent {
    imageID = "lobsterRegular";
    scale = 0.4;
    sprite = new Sprite(this.imageID, this.scale);
}
class SleepyLobster extends Agent {
    imageID = "lobsterRegular";
    scale = 0.4;
}
//# sourceMappingURL=agent.js.map