export class Model {
    agents = new Map();
    structures = new Map();
    static instance;
    constructor() { }
    static getInstance() {
        if (this.instance == null) {
            Model.instance = new Model();
        }
        return Model.instance;
    }
    // Call next tick on every simulation object
    nextTick() { }
    // Add the given agent to the simulation and ask it to broadcast
    // its initial state.
    // If an agent with the same ID already exists, throws an Error with
    // the message `Agent "${agent.id}" already exists`
    addAgent(agent) {
        this.agents.set(agent.id, agent);
    }
    // Return the agent with the specified id.
    // If no agent with that id exists, throws an Error with the message
    // `Agent "${id}" not found`
    getAgent(id) {
        if (this.agents.has(id)) {
            return this.agents.get(id);
        }
        throw new Error("Not implemented yet");
    }
    // Remove the agent with the specified id from the simulation.
    // If no agent with that id exists, throws an Error with the message
    // `Couldn't remove agent "${id}": Not found`
    removeAgent(id) {
        throw new Error("Not implemented yet");
    }
    // Add the given structure to the simulation and ask it to broadcast
    // its initial state.
    // If a structure with the same ID already exists, throws
    // an Error with the message `Structure "${structure.id}" already exists`
    addStructure(structure) { }
    // Return the structure with the specified id.
    // If no structure with that id exists, throws an Error with the message
    // `Structure ${id} not found`
    getStructure(id) {
        throw new Error("Not implemented yet");
    }
    // Remove the structure with the specified id from the simulation.
    // If no agent with that id exists, throws an Error with the message
    // `Couldn't remove structure "${id}": Not found`
    removeStructure(id) {
        throw new Error("Not implemented yet");
    }
    // Subscribe the given view to recieve updates from the model
    attach(view) { }
    // Unsubscribe the given view to recieve updates from the model
    detach(view) { }
}
//# sourceMappingURL=model.js.map