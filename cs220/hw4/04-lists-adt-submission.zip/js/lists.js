import { node, empty, reverseList } from "../include/lists.js";
export function insertOrdered(lst, el) {
    if (lst.isEmpty()) {
        return node(el, empty());
    }
    if (!lst.tail().isEmpty() && lst.head() > lst.tail().head()) {
        throw new Error("List is supposed to be increasingly ordered. Please try again with an increasingly ordered list");
    }
    if (el <= lst.head()) {
        return node(el, lst);
    }
    return node(lst.head(), insertOrdered(lst.tail(), el));
}
export function everyNRev(lst, n) {
    if (n < 0)
        throw new Error("Please pass a number >= 0 for `n`");
    let cursor = 1;
    return lst.reduce((acc, el) => {
        if (cursor === n) {
            cursor = 1;
            return node(el, acc);
        }
        else {
            cursor++;
            return acc;
        }
    }, empty());
}
export function everyNCond(lst, n, cond) {
    if (n <= 0)
        throw new Error("Please pass a positive integer for `n`");
    let cursor = 1;
    const sol = lst.filter(cond).reduce((acc, el) => {
        if (cursor === n) {
            cursor = 1;
            return node(el, acc);
        }
        cursor++;
        return acc;
    }, empty());
    return reverseList(sol);
}
export function atLeastThree(lst) {
    try {
        lst.tail().tail().head();
    }
    catch (err) {
        return false;
    }
    return true;
}
export function traverseLst(lst, cond) {
    if (!atLeastThree(lst)) {
        return empty();
    }
    let curr = lst.tail();
    let prev = lst;
    let next = curr.tail();
    let sol = empty();
    while (!curr.tail().isEmpty()) {
        if (cond(prev.head(), curr.head(), next.head()))
            sol = node(curr.head(), sol);
        prev = curr;
        curr = next;
        next = curr.tail();
    }
    return reverseList(sol);
}
export function keepTrendMiddles(lst, allSatisfy) {
    return traverseLst(lst, allSatisfy);
}
export function keepLocalMaxima(lst) {
    return traverseLst(lst, (prev, curr, next) => {
        if (prev < curr && curr > next) {
            return true;
        }
        else {
            return false;
        }
    });
}
export function keepLocalMinima(lst) {
    return traverseLst(lst, (prev, curr, next) => {
        if (prev > curr && curr < next) {
            return true;
        }
        else {
            return false;
        }
    });
}
export function keepLocalMinimaAndMaxima(lst) {
    return traverseLst(lst, (prev, curr, next) => {
        if (prev < curr && curr > next) {
            return true;
        }
        if (prev > curr && curr < next) {
            return true;
        }
        else {
            return false;
        }
    });
}
export const isPositive = (x) => Math.abs(x) === x;
export const isNegative = (x) => Math.abs(x) !== x;
export const products = (lst, cond) => {
    if (lst.isEmpty())
        return empty();
    let sol = empty();
    let prod = 1;
    let curr = lst;
    while (!curr.isEmpty()) {
        if (cond(curr.head())) {
            const newProd = curr.head() * prod;
            sol = node(newProd, sol);
            prod = newProd;
        }
        else
            prod = 1;
        curr = curr.tail();
    }
    return reverseList(sol);
};
export function nonNegativeProducts(lst) {
    return products(lst, isPositive);
}
export function negativeProducts(lst) {
    return products(lst, isNegative);
}
export function deleteFirst(lst, el) {
    if (lst.isEmpty())
        return empty();
    if (lst.head() === el)
        return lst.tail();
    else
        return node(lst.head(), deleteFirst(lst.tail(), el));
}
export function deleteLast(lst, el) {
    if (lst.isEmpty())
        return lst;
    const oldTail = lst.tail();
    const newTail = deleteLast(oldTail, el);
    if (newTail !== oldTail)
        return node(lst.head(), newTail);
    if (lst.head() === el)
        return oldTail;
    return lst;
}
export function squashList(lst) {
    if (lst.isEmpty())
        return empty();
    const head = lst.head();
    const tail = squashList(lst.tail());
    if (typeof head === "number")
        return node(head, tail);
    return node(head.reduce((acc, el) => acc + el, 0), tail);
}
//# sourceMappingURL=lists.js.map