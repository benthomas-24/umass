/**
 *  Exercise: Observer Pattern
 */
export class NewspaperApp {
    regSubscribers = new Set();
    techSubscribers = new Set();
    constructor() {
        return;
    }
    subscribe(reader, techOptIn = false) {
        this.regSubscribers.add(reader);
        if (techOptIn)
            this.techSubscribers.add(reader);
    }
    unsubscribe(reader) {
        if (!this.regSubscribers.has(reader)) {
            console.log("User is already not subscribed.");
            return;
        }
        this.regSubscribers.delete(reader);
        this.techSubscribers.delete(reader);
    }
    unsubscribeFromTechNews(reader) {
        if (!this.techSubscribers.has(reader)) {
            console.log("User is already not a subscriber to tech news.");
            return;
        }
        this.techSubscribers.delete(reader);
    }
    // notify all subscribers of a breaking news headline
    _notifyBreakingNews(headline) {
        this.regSubscribers.forEach(x => x.alert(headline));
    }
    // notify all opted-in subscribers of a technology news headline
    _notifyTechNews(headline) {
        this.techSubscribers.forEach(x => x.alert(headline));
    }
    // create a new headline in a given category
    newHeadline(headline, category) {
        switch (category) {
            case "breaking":
                this._notifyBreakingNews(headline);
                break;
            case "technology":
                this._notifyTechNews(headline);
                break;
            default:
                console.log(`Unknown headline category`);
        }
    }
}
// Example usage
class CasualReader {
    name;
    constructor(name) {
        this.name = name;
    }
    alert(headline) {
        console.log(`${this.name} will read "${headline}" for fun`);
    }
}
class MarketAnalyst {
    static getNextID = (() => {
        let id = 1;
        return () => id++;
    })();
    id = MarketAnalyst.getNextID();
    alert(headline) {
        console.log(`Market Analyst ${this.id} will analyze "${headline}" for economic implications`);
    }
}
// Create a news outlet
const CICSNews = new NewspaperApp();
// Create readers
const alice = new CasualReader("Alice");
const bob = new CasualReader("Bob");
const ma1 = new MarketAnalyst();
const ma2 = new MarketAnalyst();
// Subscribe readers to the news outlet
CICSNews.subscribe(alice, true); // Alice opts in for technology news
CICSNews.subscribe(bob, false); // Bob does not opt in for technology news
CICSNews.subscribe(ma1, true); // Market Analyst 1 opts in for technology news
CICSNews.subscribe(ma2, true); // Market Analyst 2 opts in for technology news
// Notify subscribers of technology news
CICSNews.newHeadline("Tech News: Robot Dog Learns New Trick", "technology");
console.log("");
// Unsubscribe Market Analyst 1 from the news outlet
CICSNews.unsubscribe(ma1);
console.log("Market Analyst 1 has unsubscribed from the news outlet.\n");
// Notify subscribers of breaking news
CICSNews.newHeadline("Breaking News: Snack Overflow Runs Out of Egg & Cheese Croissants", "breaking");
console.log("");
// Unsubscribe Alice from technology news
CICSNews.unsubscribeFromTechNews(alice);
console.log("Alice has unsubscribed from technology news.\n");
// Notify subscribers of another technology news headline
CICSNews.newHeadline("Tech News: Alice Unsubscribes from Technology News, So She Won't See This Headline :P", "technology");
//# sourceMappingURL=lab.js.map