#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bst.h"

// As needed, get new nodes from this array.

struct bst_node the_nodes[NUM_NODES];

// Track the number allocated so you know the next entry of
// the_nodes that is available, and can check for trying to
// allocate more than NUM_NODES nodes.

int num_allocated = 0;


void bst_add(struct bst_node **proot, char *str) {
  if (num_allocated >= NUM_NODES) {
    printf("Out of space!\n");
    exit(1);
  }
  if (*proot == NULL) {
    *proot = &the_nodes[num_allocated++];
    (*proot)->string = strdup(str);
    (*proot)->left = NULL;
    (*proot)->right = NULL;
    (*proot)->count = 1;
  } 
  else {
    int cmp = strcmp(str, (*proot)->string);
    if (cmp == 0) {
      (*proot)->count++;
    } else if (cmp < 0) {
      bst_add(&(*proot)->left, str);
    } else {
      bst_add(&(*proot)->right, str);
    }
  }
}

void bst_print(struct bst_node *root) {
  if(root == NULL) {
    return;
  }
  bst_print(root->left);
  printf("%-30s: %3d\n", root->string, root->count);
  bst_print(root->right);
}

// Used in the tests to reset the bst, don't mess with this
//   (Well, feel free to, but it will break the tests, which you probably don't
//   want to do.)
void bst_reset() {
  num_allocated = 0;
  for (int i = 0; i < NUM_NODES; i++) {
    the_nodes[i].string = NULL;
    the_nodes[i].left = NULL;
    the_nodes[i].right = NULL;
    the_nodes[i].count = 0;
  }
}
